#import eyes17.eyes          # uncomment these two lines while running stand-alone
#p = eyes17.eyes.open()
from __future__ import print_function

print (p.get_voltage('A1'))
print (p.get_voltage('A2'))
print (p.get_voltage('A3'))
